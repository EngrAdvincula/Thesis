# Instruction
This Code Base have 7 modules. 
1. idleWindow -> Which will be the default View if no one is Scanning Anything
2. main -> The main module. Ito yung tiga-run
3. qrCodeDetector -> Ito yung naga scan ng QR Code ng clients if tama yung QR Code nila
4. scanAdminAccess -> QR Code Scanner for Admin Access
5. SystemDataBase -> All the information drawn and imported from the system
6. systemProcesses -> Processing the Access logs
7. tempChecker -> Checking the temperatures

