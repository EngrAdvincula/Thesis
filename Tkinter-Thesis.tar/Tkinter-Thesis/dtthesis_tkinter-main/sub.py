import subprocess

subprocess.run("python3 main.py & python3 Exit.py", shell=True)